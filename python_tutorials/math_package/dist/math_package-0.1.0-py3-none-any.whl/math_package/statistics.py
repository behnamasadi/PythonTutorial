'''dummy stat info'''
